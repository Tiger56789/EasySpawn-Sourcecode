package de.tiger.easyspawn.main;

import java.io.File;

import org.bukkit.plugin.java.JavaPlugin;

import de.tiger.easyspawn.commands.SetSpawnCommand;
import de.tiger.easyspawn.commands.SpawnCommand;

public class Main extends JavaPlugin {
	
	private static Main plugin;
	
	public static Main getPlugin() {
		return plugin;
		
	}
	
	public void onEnable( ) {
		plugin = this;
		
		System.out.println("/////////   //////////   /////////  ///   ///");
		System.out.println("///         ///   ///    ///         /// ///");
		System.out.println("//////      ///   ///    /////////    /////     ");
		System.out.println("///         ///   ///          ///    ///      ");
		System.out.println("/////////   //////////   /////////   ///     ");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("/////////   /////////   ///////////   ///           ///   ///    ///");
		System.out.println("///         ///   ///   ///    ///     ///         ///    ////   ///");
		System.out.println("/////////   /////////   ///    ///      /// ////  ///     /// // ///");
		System.out.println("      ///   ///         ///    ///       ///// /////      ///  /////");
		System.out.println("/////////   ///         ///////////       ///   ///       ///   ////");
		getCommand("spawn").setExecutor(new SpawnCommand());
		getCommand("setspawn").setExecutor(new SetSpawnCommand());
		if (!new File(this.getDataFolder(), "config.yml").exists()) {
			this.getConfig().options().copyDefaults(true);
			this.saveConfig();
		
	}

	}

}
